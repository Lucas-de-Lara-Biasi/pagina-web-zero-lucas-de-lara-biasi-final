//Search method--------------------------------------------------------

const search_input = document.getElementById("search_input")
const search_button = document.getElementById("search_button")

function Search() {
    let search_raw = search_input.value
    console.log("Searching... (' " + search_raw + " ')")

    //check se for null ou sem nada escrito
    if (search_raw == null || search_raw == "" || typeof (search_raw) != "string") {
        return
    }

    //converter para sem espaços
    search_raw = search_raw.replaceAll(" ", "+")

    console.log(search_raw)

    //window.location.href = (window.location.href + "/search?" + search_raw)
}

search_button.addEventListener("click", Search)

//Create posts--------------------------------------------------------
const post_template = document.getElementById("post_template")
const posts_div = document.getElementById("posts_div")

let post_counter_fake = 0;

function CreatePost() {
    let post = post_template.cloneNode(true)
    post.id = post_counter_fake
    post.style = ""

    posts_div.appendChild(post)
    post_counter_fake++;
}

for (let i = 0; i < 50; i++) {
    CreatePost()
}

//Post likebuttons
