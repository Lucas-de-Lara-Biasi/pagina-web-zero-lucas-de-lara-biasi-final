//Search method

const search_input = document.getElementById("search_input")
const search_button = document.getElementById("search_button")

function Search() {
    let search_raw = search_input.value
    console.log("Searching... (' " + search_raw + " ')")

    //check se for null ou sem nada escrito
    if (search_raw == null || search_raw == "" || typeof (search_raw) != "string") {
        return
    }

    //converter para sem espaços
    search_raw = search_raw.replaceAll(" ", "+")

    console.log(search_raw)

    //window.location.href = (window.location.href + "/search?" + search_raw)
}

search_button.addEventListener("click", Search)